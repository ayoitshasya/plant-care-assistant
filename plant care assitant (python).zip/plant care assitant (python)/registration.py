import tkinter as tk
from tkinter import *
from tkinter import ttk
import mysql.connector
import time

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    port=3306,
    password="B@ngt@n7",
    database="internship"
)
mycursor = mydb.cursor()
mycursor.execute('''
    CREATE TABLE IF NOT EXISTS login (
        username VARCHAR(255),
        password VARCHAR(255)
    )
''')
mycursor.execute('''
    CREATE TABLE IF NOT EXISTS register (
        username VARCHAR(255),
        password VARCHAR(255)
    )
''')

mycursor.execute('''
        CREATE TABLE IF NOT EXISTS plants (
            id INTEGER AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(255),
            name VARCHAR(255),
            fertilizers VARCHAR(1000),
            waterschedule VARCHAR(255),
            sunlightrequirement VARCHAR(255),
            botanicalname VARCHAR(255),
            caretips VARCHAR(255),
            lifespan VARCHAR(255),
            growingseason VARCHAR(255)     
        )
    ''')

def error_destroy():
    err.destroy()


def succ_destroy():
    succ.destroy()
    root1.destroy()


def error():
    global err
    err = Toplevel(root1)
    err.title("Error")
    err.geometry("200x100")
    err.configure(bg="#f0fff0")
    Label(err, text="All fields are required...", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Label(err,bg="#f0fff0").pack()
    Button(err, text="OK", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=error_destroy).pack()


def success():
    global succ
    succ = Toplevel(root1)
    succ.title("Success")
    succ.geometry("200x100")
    succ.configure(bg="#f0fff0")
    Label(succ, text="Registration successful...", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Label(succ,bg="#f0fff0").pack()
    Button(succ, text="OK", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=succ_destroy).pack()


def registration():
    global root1
    root1 = Toplevel(root)
    root1.title("Registration Portal")
    root1.geometry("300x250")
    root1.configure(bg="#f0fff0")

    global password
    global username

    Label(root1, text="Register Your Account", font=("Helvetica", 12), bg="#f0fff0", fg="dark green", width=300).pack()
    username = StringVar()
    password = StringVar()

    Label(root1,bg="#f0fff0").pack()
    Label(root1, text="Username : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root1, textvariable=username).pack()
    Label(root1,bg="#f0fff0").pack()
    Label(root1, text="Password : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root1, textvariable=password, show="*").pack()
    Button(root1, text="Register", font=("Helvetica", 12), bg="light green", fg="dark green", command=register_user).pack()

def register_user():
    username_info = username.get()
    password_info = password.get()
    if username_info == "" or password_info == "":
        error()
    else:
        sql = "INSERT INTO login (username, password) VALUES (%s, %s)"
        t = (username_info, password_info)
        mycursor.execute(sql, t)
        mydb.commit()
        Label(root,bg="#f0fff0").pack()
        time.sleep(1)
        success()

def login():
    global root2
    root2 = Toplevel(root)
    root2.title("Login in Portal")
    root2.configure(bg="#f0fff0")
    root2.geometry("300x300")

    global username_verify
    global password_verify

    Label(root2, text="Login", font=("Helvetica", 12), bg="#f0fff0", fg="dark green", width=300).pack()
    username_verify = StringVar()
    password_verify = StringVar()

    Label(root2,bg="#f0fff0").pack()
    Label(root2, text="Username : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root2, textvariable=username_verify).pack()

    Label(root2,bg="#f0fff0").pack()
    Label(root2, text="Password : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root2, textvariable=password_verify, show="*").pack()
    Button(root2, text="Log-In", font=("Helvetica", 12), bg="light green", fg="dark green", command=login_verify).pack()
    Label(root2,bg="#f0fff0").pack()

def login_verify():
    user_verify = username_verify.get()
    pass_verify = password_verify.get()
    sql = "SELECT * FROM login WHERE username = %s AND password = %s"
    mycursor.execute(sql, [(user_verify), (pass_verify)])
    results = mycursor.fetchall()
    if results:
        for i in results:
            logged()
            break
    else:
        failed()

def logged():
    global logg
    logg = Toplevel(root2)
    logg.title("Welcome")
    logg.geometry("200x100")
    logg.configure(bg="#f0fff0")
    Label(logg, text="Welcome {}".format(username_verify.get()), fg="green",bg="#f0fff0", font="bold").pack()
    Label(logg,bg="#f0fff0").pack()
    Button(logg, text="Browse", height=1, font=("Helvetica", 12), bg="light green", fg="dark green", width=15).pack()
    Button(logg, text="Log-out", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=login_destroy).pack()



def failed():
    global fail
    fail = Toplevel(root2)
    fail.title("Invalid")
    fail.configure(bg="#f0fff0")
    fail.geometry("200x100")
    Label(fail, text="Invalid Credentials...", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Label(fail, bg="#f0fff0").pack()
    Button(fail, text="OK", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=fail_destroy).pack()

def fail_destroy():
    fail.destroy()

def login_destroy():
    logg.destroy()
    root2.destroy()

def main_screen():
    global root
    root = Tk()
    root.title("Login Portal")
    root.configure(bg="#f0fff0")
    root.geometry("300x300")
    Label(root, text="Welcome to the login portal", font=("Helvetica", 12), bg="#f0fff0", fg="dark green", width=30).pack()
    Label(root,bg="#f0fff0").pack()
    Button(root, text="Log-In", height=1, font=("Helvetica", 12), bg="light green", fg="dark green", width=8, command=login).pack()
    Label(root,bg="#f0fff0").pack()
    Button(root, text="Registration", height=1, font=("Helvetica", 12), bg="light green", fg="dark green", width=15, command=registration).pack()
    Label(root,bg="#f0fff0").pack()
    root.mainloop()




main_screen()