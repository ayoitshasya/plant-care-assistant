import tkinter as tk
from tkinter import *
from tkinter import ttk
import mysql.connector
import time

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    port=3306,
    password="abc123",
    database="mydatabase"
)
mycursor = mydb.cursor()
mycursor.execute('''
    CREATE TABLE IF NOT EXISTS login (
        username VARCHAR(255),
        password VARCHAR(255)
    )
''')
mycursor.execute('''
    CREATE TABLE IF NOT EXISTS register (
        username VARCHAR(255),
        password VARCHAR(255)
    )
''')

mycursor.execute('''
        CREATE TABLE IF NOT EXISTS plants (
            id INTEGER AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(255),
            name VARCHAR(255),
            fertilizers VARCHAR(1000),
            waterschedule VARCHAR(255),
            sunlightrequirement VARCHAR(255),
            botanicalname VARCHAR(255),
            caretip VARCHAR(255),
            lifespan VARCHAR(255),
            growingseason VARCHAR(255)     
        )
    ''')

def error_destroy():
    err.destroy()


def succ_destroy():
    succ.destroy()
    root1.destroy()


def error():
    global err
    err = Toplevel(root1)
    err.title("Error")
    err.geometry("200x100")
    err.configure(bg="#f0fff0")
    Label(err, text="All fields are required...", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Label(err,bg="#f0fff0").pack()
    Button(err, text="OK", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=error_destroy).pack()


def success():
    global succ
    succ = Toplevel(root1)
    succ.title("Success")
    succ.geometry("200x100")
    succ.configure(bg="#f0fff0")
    Label(succ, text="Registration successful...", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Label(succ,bg="#f0fff0").pack()
    Button(succ, text="OK", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=succ_destroy).pack()


def registration():
    global root1
    root1 = Toplevel(root)
    root1.title("Registration Portal")
    root1.geometry("300x250")
    root1.configure(bg="#f0fff0")

    global password
    global username

    Label(root1, text="Register Your Account", font=("Helvetica", 12), bg="#f0fff0", fg="dark green", width=300).pack()
    username = StringVar()
    password = StringVar()

    Label(root1,bg="#f0fff0").pack()
    Label(root1, text="Username : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root1, textvariable=username).pack()
    Label(root1,bg="#f0fff0").pack()
    Label(root1, text="Password : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root1, textvariable=password, show="*").pack()
    Button(root1, text="Register", font=("Helvetica", 12), bg="light green", fg="dark green", command=register_user).pack()

def register_user():
    username_info = username.get()
    password_info = password.get()
    if username_info == "" or password_info == "":
        error()
    else:
        sql = "INSERT INTO login (username, password) VALUES (%s, %s)"
        t = (username_info, password_info)
        mycursor.execute(sql, t)
        mydb.commit()
        Label(root,bg="#f0fff0").pack()
        time.sleep(1)
        success()

def login():
    global root2
    root2 = Toplevel(root)
    root2.title("Login in Portal")
    root2.configure(bg="#f0fff0")
    root2.geometry("300x300")

    global username_verify
    global password_verify

    Label(root2, text="Login", font=("Helvetica", 12), bg="#f0fff0", fg="dark green", width=300).pack()
    username_verify = StringVar()
    password_verify = StringVar()

    Label(root2,bg="#f0fff0").pack()
    Label(root2, text="Username : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root2, textvariable=username_verify).pack()

    Label(root2,bg="#f0fff0").pack()
    Label(root2, text="Password : ", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Entry(root2, textvariable=password_verify, show="*").pack()
    Button(root2, text="Log-In", font=("Helvetica", 12), bg="light green", fg="dark green", command=login_verify).pack()
    Label(root2,bg="#f0fff0").pack()

def login_verify():
    user_verify = username_verify.get()
    pass_verify = password_verify.get()
    sql = "SELECT * FROM login WHERE username = %s AND password = %s"
    mycursor.execute(sql, [(user_verify), (pass_verify)])
    results = mycursor.fetchall()
    if results:
        for i in results:
            logged()
            break
    else:
        failed()

def logged():
    global logg
    logg = Toplevel(root2)
    logg.title("Welcome")
    logg.geometry("200x100")
    logg.configure(bg="#f0fff0")
    Label(logg, text="Welcome {}".format(username_verify.get()), fg="green",bg="#f0fff0", font="bold").pack()
    Label(logg,bg="#f0fff0").pack()
    Button(logg, text="Plant Options", height=1, font=("Helvetica", 12), bg="light green", fg="dark green", width=15,command=plant_option).pack()
    Button(logg, text="Log-out", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=login_destroy).pack()
    

def failed():
    global fail
    fail = Toplevel(root2)
    fail.title("Invalid")
    fail.configure(bg="#f0fff0")
    fail.geometry("200x100")
    Label(fail, text="Invalid Credentials...", font=("Helvetica", 12), bg="#f0fff0", fg="dark green").pack()
    Label(fail, bg="#f0fff0").pack()
    Button(fail, text="OK", font=("Helvetica", 12), bg="light green", fg="dark green", width=8, height=1, command=fail_destroy).pack()

def fail_destroy():
    fail.destroy()

def login_destroy():
    logg.destroy()
    root2.destroy()

def main_screen():
    global root
    root = Tk()
    root.title("Login Portal")
    root.configure(bg="#f0fff0")
    root.geometry("300x300")
    Label(root, text="Welcome to the login portal", font=("Helvetica", 12), bg="#f0fff0", fg="dark green", width=30).pack()
    Label(root,bg="#f0fff0").pack()
    Button(root, text="Log-In", height=1, font=("Helvetica", 12), bg="light green", fg="dark green", width=8, command=login).pack()
    Label(root,bg="#f0fff0").pack()
    Button(root, text="Registration", height=1, font=("Helvetica", 12), bg="light green", fg="dark green", width=15, command=registration).pack()
    Label(root,bg="#f0fff0").pack()
    root.mainloop()

def plant_option():
    user_selection()

def user_selection () :
    def display_plant_options(event):
        selected_type = plant_type_var.get()
        plant_options_combobox['values'] = get_plant_options(selected_type)

    def get_plant_options(selected_type):
        if selected_type == "Flower Plants":
            return flower_plants_list
        elif selected_type == "Herbal Plants":
            return herbal_plants_list
        elif selected_type == "Indoor Plants":
            return indoor_plants_list
        elif selected_type == "Ornamental Plants":
            return ornamental_plants_list
        elif selected_type == "Hanging and Creeper Plants":
            return hanging_creeper_plants_list
        elif selected_type == "Fruit Plants":
            return fruit_plants_list
        elif selected_type == "Vegetable Plants":
            return vegetable_plants_list
        elif selected_type == "Aquatic Plants":
            return aquatic_plants_list
        elif selected_type == "Croton Plants":
            return croton_plants_list
    def select_plant():
        selected_plant = plant_options_combobox.get()
        if selected_plant:
            result_label.config(text=f"You selected: {selected_plant}", fg="dark green")

    flower_plants_list = [
        "Rose (All Varieties)",
        "Crape Layered Jasmine",
        "Kodai Malli",
        "Mussaenda Yellow Mini",
        "Nerium Oleander Plant White",
        "Crossandra Yellow",
        "Bulb Sampangi Plant",
        "Allamanda Bush Yellow Plant",
        "Singapuri Ixora Red Plant",
        "Mussaenda Red Plant",
        "Kesavardhini Plant",
        "Fragrance Kagattan Plant",
        "Pavala Malli - Night Blooming Jasmine Plant",
        "Malabar Nut Plant",
        "Clitoria Ternatea Plant",
        "Nerium (Oleander)",
        "Mussaenda",
        "Ixora",
        "Allamanda",
        "Tecoma",
        "Hibiscus",
        "Crossandra",
        "Crape Jasmine",
        "Jasmine",
        "Parijatham (Nyctanthes Arbor-Tristis)",
        "Kagattan (Lagerstroemia Spp.)",
        "Periwinkle (Catharanthus Roseus)",
        "Sampangi (Tuberose)",
        "Chrysanthemum (Sevanthi)",
        "Marigold (Tagetes Spp.)"
    ]

    herbal_plants_list = [
        "Black Nochi (Vitex Negundo)",
        "Clitoria Ternatea (Butterfly Pea)",
        "Insulin Plant (Costus Igneus)",
        "Kesavardhini Plant (Croton)",
        "Madagascar Periwinkle Pink (Catharanthus Roseus)",
        "Mudakathan-Balloon Vine (Cardiospermum Halicacabum)",
        "Multivitamin Plant (Amaranthus Tricolor)",
        "Noni Fruit (Morinda Citrifolia)",
        "Piper Betle Leaves Plant (Betel Leaf)",
        "Coleus Amboinicus (Country Borage)",
        "Henna Plant (Lawsonia Inermis)",
        "Herb Nochi Plant (Vitex Negundo)",
        "Holy Basil Plant (Ocimum Tenuiflorum)",
        "Malabar Nut Plant (Justicia Adhatoda)",
        "Morinda Citrifolia (Indian Mulberry)",
        "Andrographis Paniculata (Green Chiretta)"
    ]

    indoor_plants_list = [
        "Philodendron",
        "Money Plant (Epipremnum Aureum, Devil's Ivy, Pothos)",
        "Syngonium",
        "Alocasia",
        "Aglaonema",
        "Caladium",
        "Ferns"
    ]

    ornamental_plants_list = [
        "Dracaena",
        "Ti-plants (Cordyline)",
        "Ficus",
        "Hedge Plants (e.g., Ligustrum, Buxus)",
        "Aralia"
    ]

    hanging_creeper_plants_list = [
        "Alternanthera Ficoidea True Yellow",
        "Alternanthera Ficoidea White Carpet",
        "Alternanthera Green",
        "Alternanthera",
        "Parrot Leaf 'Red Carpet'",
        "Callisia Dragon Tail Plant",
        "Callisia Repens-Turtle Vine Plant",
        "Clitoria Ternatea-White Multi Petaled",
        "Cupid Peperomia Plant",
        "Hanging Pedilanthus-(Curly Leaves Variegated)",
        "Inch Plant Deep Purple (Tradescantia Pallida)",
        "Melastoma Malabathricum-Indian Rhododendron",
        "Mexican Petunia Purple Showers (Ruellia Simplex)",
        "Pellionia Repens-Trailing Watermelon Begonia",
        "Purple Heart (Tradescantia Pallida) Plant",
        "Tradescantia Spathacea- Rheo Green",
        "Tradescantia Zebrina",
        "Bush Clock Laurifolia Blue",
        "Bush Clock Vine White",
        "Garlic Creeper Plant (Blue)",
        "Japanese Honeysuckle",
        "Passion Flowers Red",
        "Thunbergia Grandiflora Blue",
        "Rangoon Creeper Plant",
        "Bignonia-Amphilophium Paniculatum"
    ]

    fruit_plants_list = [
        "L49 White Guava (Lucknow49)",
        "Mini Orange",
        "Star Gooseberry (Phyllanthus Acidus)",
        "Allahabad Safeda Guava Plant",
        "Arka Kiran Guava (Pink Koiyya Plant)",
        "Barbados Cherry Plant",
        "Dragon Fruit Plant",
        "Mini Guava Green",
        "Water Apple Red",
        "Aegle Marmelos (Kasi Vilvam)",
        "Jamun Fruit (Naval Maram)",
        "Kadamba Tree",
        "Indian Tulip Tree",
        "Kumizh (Gmelina Arborea Tree - White Teak)",
        "Madras Thorn Plant (Kodukka Puli)",
        "Casuarina Plant (Savukku Maram)",
        "Lakshmi Tree (Simarouba Glauca)",
        "Mahua Tree (Iluppai Maram)",
        "Apple Plant",
        "Mango Plant",
        "Lychee Plant",
        "Avocado Plant"
    ]

    vegetable_plants_list = [
        "Bitter Gourd Plant (Paavakkaai)",
        "Pumpkin Plant (Parangikai)",
        "Fava Beans/Broad Beans (Avarai)",
        "Brinjal Plant",
        "Ash Pumpkin Plant",
        "Spinach Plant",
        "Lettuce Plant",
        "Radishes Plant",
        "Potatoes PLant",
        "Tomatoes Plant",
        "Salad Leaves",
        "Spring Onion Plant",
        "Carrot Plant",
        "Beetroot Plant"
    ]

    aquatic_plants_list = [
        "3 Pink Lotus Tuber",
        "3 White Lily Plant",
        "Hydrocleys Nymphoides",
        "Ludwigia Sedoides",
        "Rhynchospora Colorata",
        "Water Lily Plant",
        "Water Lily Purple Plant"
    ]

    croton_plants_list = [
        "Croton Plants",
        "Acalpha Wilkesiana - Jacob’s Coat",
        "Acalypha Copper Plant - Dragon Fire",
        "Aralia Green Plant",
        "Aralia Variegated White",
        "Carpentaria Palm",
        "Chinese Hat Flower",
        "Carmona Microphylla - Fukien Tea Croton",
        "Cordyline 'Chocolate Queen'",
        "Cordyline Fruticosa 'Celestial Queen'",
        "Cordyline Fruticosa 'Inscripta'",
        "Duck Foot Plant",
        "Euphorbia Tithymaloides Variegated Plant",
        "Gold Dust (Small Leaf)",
        "Hybrid Ti Plant",
        "Pandanus Tectorius - Screw Pine",
        "Pedilanthus Tithymaloides",
        "Polyscias Fruticosa Plant",
        "Song of India Green Plant"
    ]
    
    root3=tk.Toplevel(root2)
    root3.title("Plant Care Assistance")
    root3.configure(bg="#f0fff0")

    Label(root3, text="Welcome to Plant Care Assistance", font=("Helvetica", 16), bg="#f0fff0", fg="dark green",pady=10).pack()
   
    plant_type_var = tk.StringVar()
    plant_type_label = tk.Label(root3, text="Type of Plants", font=("Helvetica", 12), bg="#f0fff0", fg="dark green")
    plant_type_combobox = ttk.Combobox(root, textvariable=plant_type_var, values=[
        "Flower Plants", "Herbal Plants", "Indoor Plants", "Ornamental Plants",
        "Hanging and Creeper Plants", "Fruit Plants", "Vegetable Plants", "Aquatic Plants", "Croton Plants"
    ], state="readonly", background="#f0fff0")

    plant_type_combobox.bind("<<ComboboxSelected>>", display_plant_options)

    plant_type_label.pack(pady=10)
    plant_type_combobox.pack(pady=10)

    plant_options_label = tk.Label(root3, text="Plant Options", font=("Helvetica", 12), bg="#f0fff0", fg="dark green")
    plant_options_var = tk.StringVar()
    plant_options_combobox = ttk.Combobox(root3, textvariable=plant_options_var, state="readonly", background="light green")
    plant_options_label.pack(pady=10)
    plant_options_combobox.pack(pady=10)

    select_button = tk.Button(root3, text="Select Plant", command=select_plant, bg="light green", fg="dark green")
    select_button.pack(pady=10)

    result_label = tk.Label(root3, text="", font=("Helvetica", 12), bg="#f0fff0", fg="dark green")
    result_label.pack(pady=10)

    root.mainloop()


main_screen()