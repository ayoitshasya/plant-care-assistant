import tkinter as tk
from tkinter import ttk

def display_plant_options():
    selected_type = plant_type_var.get()
    plant_options_combobox['values'] = get_plant_options(selected_type)

def get_plant_options(selected_type):
    if selected_type == "Flower Plants":
        return flower_plants_list
    elif selected_type == "Herbal Plants":
        return herbal_plants_list
    elif selected_type == "Indoor Plants":
        return indoor_plants_list
    elif selected_type == "Ornamental Plants":
        return ornamental_plants_list
    elif selected_type == "Hanging and Creeper Plants":
        return hanging_creeper_plants_list
    elif selected_type == "Fruit Plants":
        return fruit_plants_list
    elif selected_type == "Vegetable Plants":
        return vegetable_plants_list
    elif selected_type == "Aquatic Plants":
        return aquatic_plants_list
    elif selected_type == "Croton Plants":
        return croton_plants_list

def select_plant():
    selected_plant = plant_options_combobox.get()
    if selected_plant:
        display_plant_details(selected_plant)

def display_plant_details(plant_name):
    details_window = tk.Toplevel(root)
    details_window.title(f"Details for {plant_name}")
    details_label = tk.Label(details_window, text=plant_details[plant_name], font=("Helvetica", 12), bg="#f0fff0", fg="dark green")
    details_label.pack(pady=10)

flower_plants_list = [
    "Rose (All Varieties)",
    "Crape Layered Jasmine",
    "Kodai Malli",
    "Mussaenda Yellow Mini",
    "Nerium Oleander Plant White",
    "Crossandra Yellow",
    "Bulb Sampangi Plant",
    "Allamanda Bush Yellow Plant",
    "Singapuri Ixora Red Plant",
    "Mussaenda Red Plant",
    "Kesavardhini Plant",
    "Fragrance Kagattan Plant",
    "Pavala Malli - Night Blooming Jasmine Plant",
    "Malabar Nut Plant",
    "Clitoria Ternatea Plant",
    "Nerium (Oleander)",
    "Mussaenda",
    "Ixora",
    "Allamanda",
    "Tecoma",
    "Hibiscus",
    "Crossandra",
    "Crape Jasmine",
    "Jasmine",
    "Parijatham (Nyctanthes Arbor-Tristis)",
    "Kagattan (Lagerstroemia Spp.)",
    "Periwinkle (Catharanthus Roseus)",
    "Sampangi (Tuberose)",
    "Chrysanthemum (Sevanthi)",
    "Marigold (Tagetes Spp.)"
]

herbal_plants_list = [
    "Black Nochi (Vitex Negundo)",
    "Clitoria Ternatea (Butterfly Pea)",
    "Insulin Plant (Costus Igneus)",
    "Kesavardhini Plant (Croton)",
    "Madagascar Periwinkle Pink (Catharanthus Roseus)",
    "Mudakathan-Balloon Vine (Cardiospermum Halicacabum)",
    "Multivitamin Plant (Amaranthus Tricolor)",
    "Noni Fruit (Morinda Citrifolia)",
    "Piper Betle Leaves Plant (Betel Leaf)",
    "Coleus Amboinicus (Country Borage)",
    "Henna Plant (Lawsonia Inermis)",
    "Herb Nochi Plant (Vitex Negundo)",
    "Holy Basil Plant (Ocimum Tenuiflorum)",
    "Malabar Nut Plant (Justicia Adhatoda)",
    "Morinda Citrifolia (Indian Mulberry)",
    "Andrographis Paniculata (Green Chiretta)"
]

indoor_plants_list = [
    "Philodendron",
    "Money Plant (Epipremnum Aureum, Devil's Ivy, Pothos)",
    "Syngonium",
    "Alocasia",
    "Aglaonema",
    "Caladium",
    "Ferns"
]

ornamental_plants_list = [
    "Dracaena",
    "Ti-plants (Cordyline)",
    "Ficus",
    "Hedge Plants (e.g., Ligustrum, Buxus)",
    "Aralia"
]

hanging_creeper_plants_list = [
    "Alternanthera Ficoidea “True Yellow”",
    "Alternanthera Ficoidea White Carpet",
    "Alternanthera Green",
    "Alternanthera",
    "Parrot Leaf ‘Red Carpet’",
    "Callisia Dragon Tail Plant",
    "Callisia Repens-Turtle Vine Plant",
    "Clitoria Ternatea-White Multi Petaled",
    "Cupid Peperomia Plant",
    "Hanging Pedilanthus-(Curly Leaves Variegated)",
    "Inch Plant Deep Purple (Tradescantia Pallida)",
    "Melastoma Malabathricum-Indian Rhododendron",
    "Mexican Petunia Purple Showers (Ruellia Simplex)",
    "Pellionia Repens-Trailing Watermelon Begonia",
    "Purple Heart (Tradescantia Pallida) Plant",
    "Tradescantia Spathacea- Rheo Green",
    "Tradescantia Zebrina",
    "Bush Clock Laurifolia Blue",
    "Bush Clock Vine White",
    "Garlic Creeper Plant (Blue)",
    "Japanese Honeysuckle",
    "Passion Flowers Red",
    "Thunbergia Grandiflora Blue",
    "Rangoon Creeper Plant",
    "Bignonia-Amphilophium Paniculatum"
]

fruit_plants_list = [
    "L49 White Guava (Lucknow49)",
    "Mini Orange",
    "Star Gooseberry (Phyllanthus Acidus)",
    "Allahabad Safeda Guava Plant",
    "Arka Kiran Guava (Pink Koiyya Plant)",
    "Barbados Cherry Plant",
    "Dragon Fruit Plant",
    "Mini Guava Green",
    "Water Apple Red",
    "Aegle Marmelos (Kasi Vilvam)",
    "Jamun Fruit (Naval Maram)",
    "Kadamba Tree",
    "Indian Tulip Tree",
    "Kumizh (Gmelina Arborea Tree - White Teak)",
    "Madras Thorn Plant (Kodukka Puli)",
    "Casuarina Plant (Savukku Maram)",
    "Lakshmi Tree (Simarouba Glauca)",
    "Mahua Tree (Iluppai Maram)",
    "Apple Plant",
    "Mango Plant",
    "Lychee Plant",
    "Avocado Plant"
]

vegetable_plants_list = [
    "Bitter Gourd Plant (Paavakkaai)",
    "Pumpkin Plant (Parangikai)",
    "Fava Beans/Broad Beans (Avarai)",
    "Brinjal Plant",
    "Ash Pumpkin Plant",
    "Spinach Plant",
    "Lettuce Plant",
    "Radishes Plant",
    "Potatoes PLant",
    "Tomatoes Plant",
    "Salad Leaves",
    "Spring Onion Plant",
    "Carrot Plant",
    "Beetroot Plant"
]

aquatic_plants_list = [
    "3 Pink Lotus Tuber",
    "3 White Lily Plant",
    "Hydrocleys Nymphoides",
    "Ludwigia Sedoides",
    "Rhynchospora Colorata",
    "Water Lily Plant",
    "Water Lily Purple Plant"
]

croton_plants_list = [
    "Croton Plants",
    "Acalpha Wilkesiana - Jacob’s Coat",
    "Acalypha Copper Plant - Dragon Fire",
    "Aralia Green Plant",
    "Aralia Variegated White",
    "Carpentaria Palm",
    "Chinese Hat Flower",
    "Carmona Microphylla - Fukien Tea Croton",
    "Cordyline 'Chocolate Queen'",
    "Cordyline Fruticosa 'Celestial Queen'",
    "Cordyline Fruticosa 'Inscripta'",
    "Duck Foot Plant",
    "Euphorbia Tithymaloides Variegated Plant",
    "Gold Dust (Small Leaf)",
    "Hybrid Ti Plant",
    "Pandanus Tectorius - Screw Pine",
    "Pedilanthus Tithymaloides",
    "Polyscias Fruticosa Plant",
    "Song of India Green Plant"
]

plant_details = {
    "Rose (All varieties)":"""
   - Fertilizer: Use a rose fertilizer with a balanced N-P-K ratio, such as Bayer Advanced Rose and Flower Care (14-12-11). Apply in spring and mid-summer.
   - Water Schedule: Water deeply once a week or when the top 2 inches of soil are dry. Ensure good drainage to prevent waterlogged soil.
   - Sunlight Requirement: Full sun (at least 6 hours of direct sunlight per day).
   - Botanical Name: Rosa spp.
   - Care Tips: Prune regularly to shape the plant, remove dead or diseased wood, and encourage air circulation.
   - Lifespan: Varies by variety, generally 5-30 years.
   - Growing Season: Spring to fall.
    """,
    "Crape Layered Jasmine":"""
   - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied in spring and summer.
   - Water Schedule: Keep the soil consistently moist, allowing the top inch to dry between watering.
   - Sunlight Requirement: Full to partial sunlight (6-8 hours of sunlight per day).
   - Botanical Name: Jasminum multiflorum
   - Care Tips: Prune after flowering to maintain shape and encourage new growth. Provide support for climbing varieties.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Kodai Malli":"""
   - Fertilizer: Use a high-phosphorus fertilizer, like 5-10-5, during the flowering season.
   - Water Schedule: Keep the soil consistently moist, reducing watering in winter.
   - Sunlight Requirement: Full sunlight for at least 6 hours a day.
   - Botanical Name: Tabernaemontana divaricata
   - Care Tips: Prune after flowering to shape the plant. Protect from cold drafts.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Mussaenda Yellow Mini":"""
   - Fertilizer: Use a balanced fertilizer every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist, allowing the top inch to dry between watering.
   - Sunlight Requirement: Partial to full sunlight.
   - Botanical Name: Mussaenda philippica
   - Care Tips: Prune after flowering to encourage bushiness. Mulch to retain soil moisture.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Nerium Oleander Plant White":"""
   - Fertilizer: Feed with a slow-release fertilizer in spring.
   - Water Schedule: Allow the soil to dry between watering. Water sparingly in winter.
   - Sunlight Requirement: Full sunlight.
   - Botanical Name: Nerium oleander
   - Care Tips: Prune to shape in late winter or early spring. Beware of toxicity.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Crossandra Yellow":"""
   - Fertilizer: Use a balanced liquid fertilizer every 2-3 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist.
   - Sunlight Requirement: Partial shade.
   - Botanical Name: Crossandra infundibuliformis
   - Care Tips: Pinch back to encourage bushiness. Protect from drafts.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Bulb Sampangi Plant":"""
   - Fertilizer: Use a balanced fertilizer with a higher phosphorus content in spring.
   - Water Schedule: Keep the soil evenly moist during the growing season, reducing in winter.
   - Sunlight Requirement: Full to partial sunlight.
   - Botanical Name: Magnolia champaca
   - Care Tips: Provide well-draining soil. Mulch to conserve moisture.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Allamanda Bush Yellow Plant":"""
   - Fertilizer: Feed with a high-phosphorus fertilizer every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist.
   - Sunlight Requirement: Full sunlight.
   - Botanical Name: Allamanda cathartica
   - Care Tips: Prune to shape after flowering. Protect from frost.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Singapuri Ixora Red Plant":"""
   - Fertilizer: Use a balanced fertilizer with micronutrients every 4 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist.
   - Sunlight Requirement: Full to partial sunlight.
   - Botanical Name: Ixora singaporensis
   - Care Tips: Prune to shape after flowering. Mulch to retain moisture.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Mussaenda Red Plant":"""
   - Fertilizer: Apply a balanced fertilizer every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist.
   - Sunlight Requirement: Partial to full sunlight.
   - Botanical Name: Mussaenda erythrophylla
   - Care Tips: Prune to maintain shape and size. Protect from cold drafts.
   - Lifespan: Perennial
   - Growing Season: Spring and summer
    """,
    "Kesavardhini Plant":"""
    - Fertilizer: Use a balanced fertilizer every 4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Partial to full sunlight.
    - Botanical Name: Mussaenda frondosa
    - Care Tips: Prune to control size and shape. Mulch to retain soil moisture.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Fragrance Kagattan Plant":"""
    - Fertilizer: Apply a balanced liquid fertilizer every 2-3 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Partial shade.
    - Botanical Name: Gardenia jasminoides
    - Care Tips: Prune after flowering to shape the plant. Provide high humidity.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Pavala Malli - Night Blooming Jasmine Plant":"""
    - Fertilizer: Use a high-phosphorus fertilizer in spring and summer.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Cestrum nocturnum
    - Care Tips: Prune to shape and control size. Enjoy the fragrance in the evening.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """, 
    "Malabar Nut Plant":"""
    - Fertilizer: Use a balanced fertilizer every 4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Justicia adhatoda
    - Care Tips: Prune to encourage bushiness. Protect from extreme cold.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Clitoria Ternatea Plant":"""
    - Fertilizer: Use a balanced fertilizer with higher phosphorus during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Clitoria ternatea
    - Care Tips: Provide support for climbing varieties. Prune to control size.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Nerium (Oleander)":"""
   - Fertilizer: Use a balanced fertilizer like Miracle-Gro Water Soluble Bloom Booster Flower Food (15-30-15). Apply in spring and mid-summer.
   - Water Schedule: Water deeply and infrequently, allowing the soil to dry out between waterings.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Nerium oleander.
   - Care Tips: Prune after flowering to maintain shape and remove dead wood.
   - Lifespan: Can live for several decades.
   - Growing Season: Spring to fall.
    """,
    "Mussaenda":"""
   - Fertilizer: Use a balanced fertilizer, such as Miracle-Gro Water Soluble All Purpose Plant Food (24-8-16). Apply during the growing season.
   - Water Schedule: Keep the soil consistently moist but not waterlogged.
   - Sunlight Requirement: Partial to full sun.
   - Botanical Name: Mussaenda spp.
   - Care Tips: Prune after flowering to maintain shape and encourage bushiness.
   - Lifespan: Varies by species.
   - Growing Season: Spring and summer.
    """,
    "Ixora":"""
   - Fertilizer: Use a specialized ixora fertilizer or a balanced fertilizer with micronutrients, such as Osmocote Flower and Vegetable Smart-Release Plant Food (14-14-14).
   - Water Schedule: Keep the soil consistently moist.
   - Sunlight Requirement: Full to partial sun.
   - Botanical Name: Ixora spp.
   - Care Tips: Prune regularly to maintain shape and remove dead or diseased branches.
   - Lifespan: Several decades.
   - Growing Season: Spring and summer.
    """,
    "Allamanda":"""
   - Fertilizer: Use a high-phosphorus fertilizer like Miracle-Gro Water Soluble Bloom Booster Flower Food (15-30-15). Apply during the growing season.
   - Water Schedule: Keep the soil consistently moist but not waterlogged.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Allamanda spp.
   - Care Tips: Prune to control size and shape after flowering.
   - Lifespan: Varies by species.
   - Growing Season: Spring and summer.
    """,
    "Tecoma":"""
   - Fertilizer: Use a general-purpose balanced fertilizer, such as Osmocote Flower and Vegetable Smart-Release Plant Food (14-14-14). Apply during the growing season.
   - Water Schedule: Allow the soil to dry between waterings. Water deeply.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Tecoma spp.
   - Care Tips: Prune in late winter or early spring to shape the plant.
   - Lifespan: Varies by species.
   - Growing Season: Spring to fall.
    """,
    "Hibiscus":"""
   - Fertilizer: Use a fertilizer formulated for hibiscus, such as Miracle-Gro Water Soluble Hibiscus Plant Food (10-4-12). Apply during the growing season.
   - Water Schedule: Keep the soil consistently moist but not waterlogged.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Hibiscus spp.
   - Care Tips: Prune to shape and remove dead or weak branches regularly.
   - Lifespan: 5-10 years.
   - Growing Season: Spring to fall.
    """,
    "Crossandra":"""
   - Fertilizer: Apply a balanced fertilizer with micronutrients, such as Miracle-Gro Water Soluble All Purpose Plant Food (24-8-16). Apply during the growing season.
   - Water Schedule: Keep the soil consistently moist.
   - Sunlight Requirement: Partial shade to full sun.
   - Botanical Name: Crossandra spp.
   - Care Tips: Pinch back to encourage bushiness.
   - Lifespan: Varies by species.
   - Growing Season: Spring and summer.
    """,
    "Crape Jasmine":"""
   - Fertilizer: Use a general-purpose balanced fertilizer, such as Osmocote Flower and Vegetable Smart-Release Plant Food (14-14-14). Apply during the growing season.
   - Water Schedule: Keep the soil consistently moist.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Tabernaemontana divaricata.
   - Care Tips: Prune after flowering to shape the plant.
   - Lifespan: Several decades.
   - Growing Season: Spring and summer.
    """,
    "Jasmine":"""
    - Fertilizer: Apply a balanced fertilizer like Miracle-Gro Water Soluble All Purpose Plant Food (24-8-16). Apply during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Jasminum spp.
    - Care Tips: Prune after flowering to maintain shape.
    - Lifespan: Varies by species.
    - Growing Season: Spring and summer.
    """, 
    "December Poo (Narcissus)":"""
    - Fertilizer: Use a bulb fertilizer with higher phosphorus, such as Osmocote Smart-Release Flower and Vegetable Plant Food (14-14-14). Apply before and during blooming.
    - Water Schedule: Keep the soil consistently moist during the growing season.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Narcissus spp.
    - Care Tips: Allow foliage to die back naturally after flowering.
    - Lifespan: Perennial.
    - Growing Season: Spring.
    """,
    "Parijatham (Nyctanthes arbor-tristis)":"""
    - Fertilizer: Apply a balanced fertilizer like Miracle-Gro Water Soluble All Purpose Plant Food (24-8-16). Apply during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Nyctanthes arbor-tristis.
    - Care Tips: Prune to maintain shape and remove dead wood.
    - Lifespan: Several decades.
    - Growing Season: Spring and summer.
    """,
    "Kagattan (Lagerstroemia spp.)":"""
    - Fertilizer: Use a general-purpose balanced fertilizer, such as Osmocote Flower and Vegetable Smart-Release Plant Food (14-14-14). Apply during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Lagerstroemia spp.
    - Care Tips: Prune in late winter or early spring to shape the plant.
    - Lifespan: Varies by species.
    - Growing Season: Spring and summer.
    """, 
    "Periwinkle (Catharanthus roseus)":"""
    - Fertilizer: Apply a balanced fertilizer like Miracle-Gro Water Soluble All Purpose Plant Food (24-8-16). Apply during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Catharanthus roseus.
    - Care Tips: Pinch back to encourage bushiness.
    - Lifespan: Annual or perennial, depending on the variety.
    - Growing Season: Spring and summer.
    """, 
    "Sampangi (Tuberose)":"""
    - Fertilizer: Use a bulb fertilizer or a balanced fertilizer like Osmocote Smart-Release Flower and Vegetable Plant Food (14-14-14). Apply before and during blooming.
    - Water Schedule: Keep the soil consistently moist during the growing season.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Polianthes tuberosa.
    - Care Tips: Provide support for tall flower spikes.
    - Lifespan: Perennial.
    - Growing Season: Spring and summer.
    """,
    "Chrysanthemum (Sevanthi)":"""
    - Fertilizer: Use a specialized chrysanthemum fertilizer or a balanced fertilizer with higher phosphorus, such as Osmocote Smart-Release Flower and Vegetable Plant Food (14-14-14). Apply during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Chrysanthemum spp.
    - Care Tips: Pinch back to encourage bushiness.
    - Lifespan: Annual or perennial, depending on the variety.
    - Growing Season: Spring and fall.
    """,
    "Marigold (Tagetes spp.)":"""
    - Fertilizer: Apply a balanced fertilizer like Miracle-Gro Water Soluble All Purpose Plant Food (24-8-16). Apply during the growing season.
    - Water Schedule: Keep the soil consistently moist.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Tagetes spp.
    - Care Tips: Pinch back to encourage bushiness.
    - Lifespan: Annual.
    - Growing Season: Spring and summer.
    """,
    "Black Nochi (Vitex negundo)": """ 
    - Fertilizer: Use a balanced fertilizer, such as a 10-10-10, during the growing season. Apply in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist, watering when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight, at least 4-6 hours of direct sunlight daily.
    - Botanical Name: Vitex negundo
    - Care Tips: Prune to maintain shape. Protect from frost in colder climates.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Clitoria Ternatea (Butterfly Pea)": """
    - Fertilizer: Use a balanced fertilizer with a higher phosphorus content (10-20-10) to promote flowering. Apply in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal flowering.
    - Botanical Name: Clitoria ternatea
    - Care Tips: Provide support for climbing varieties. Prune to encourage bushier growth.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Insulin Plant (Costus igneus)":"""
    - Fertilizer: Use a balanced fertilizer during the growing season. Apply in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Partial sunlight, with filtered sunlight during the hottest part of the day.
    - Botanical Name: Costus igneus
    - Care Tips: Protect from cold temperatures. Mulch to conserve soil moisture.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Kesavardhini Plant (Croton)":"""
    - Fertilizer: Use a balanced, slow-release fertilizer in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for vibrant leaf colors.
    - Botanical Name: Codiaeum variegatum
    - Care Tips: Prune for shape and size control. Watch for pests.
    - Lifespan: Perennial
    - Growing Season: Year-round in warm climates
    """,
    "Madagascar Periwinkle Pink (Catharanthus roseus)":"""
    - Fertilizer: Use a balanced, water-soluble fertilizer every 2-4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal flowering.
    - Botanical Name: Catharanthus roseus
    - Care Tips: Pinch back for bushier growth. Watch for pests.
    - Lifespan: Annual or perennial
    - Growing Season: Spring and summer
    """,
    "Mudakathan-Balloon Vine (Cardiospermum halicacabum)":"""
    - Fertilizer: Use a balanced fertilizer during the growing season. Apply in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Cardiospermum halicacabum
    - Care Tips: Provide support for climbing varieties. Prune to control size.
    - Lifespan: Annual or perennial
    - Growing Season: Spring and summer
    """,
    "Multivitamin Plant (Amaranthus tricolor)":"""
    - Fertilizer: Use a balanced fertilizer with micronutrients every 2-4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for vibrant leaf colors.
    - Botanical Name: Amaranthus tricolor
    - Care Tips: Pinch back for bushier growth. Harvest leaves for consumption.
    - Lifespan: Annual
    - Growing Season: Spring and summer
    """,
    "Noni Fruit (Morinda citrifolia)":"""
    - Fertilizer: Use a balanced fertilizer with micronutrients every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal fruiting.
    - Botanical Name: Morinda citrifolia
    - Care Tips: Prune to control size. Protect from cold temperatures.
    - Lifespan: Perennial
    - Growing Season: Year-round in warm climates
    """,
    "Piper Betle Leaves Plant (Betel Leaf)":"""
    - Fertilizer: Use a balanced fertilizer with micronutrients every 2-4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Partial sunlight.
    - Botanical Name: Piper betle
    - Care Tips: Provide support for climbing varieties. Harvest leaves for consumption.
    - Lifespan: Perennial
    - Growing Season: Year-round in warm climates
    """, 
    "Coleus Amboinicus (Country Borage)":"""
    - Fertilizer: Use a balanced fertilizer with a higher nitrogen content (10-5-5) every 2-4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Partial sunlight.
    - Botanical Name: Plectranthus amboinicus
    - Care Tips: Pinch back for bushier growth. Harvest leaves for culinary use.
    - Lifespan: Perennial
    - Growing Season: Year-round in warm climates
    """,
    "Henna Plant (Lawsonia inermis)":"""
    - Fertilizer: Use a balanced fertilizer, such as a 10-10-10, during the growing season. Apply in spring and mid-summer.
    - Water Schedule: Allow the soil to dry between waterings.
    - Sunlight Requirement: Full sunlight for optimal dye production.
    - Botanical Name: Lawsonia inermis
    - Care Tips: Prune to control size. Harvest leaves for henna dye.
    - Lifespan: Perennial
    - Growing Season: Year-round in warm climates
    """,
    "Herb Nochi Plant (Vitex negundo)":"""
    - Fertilizer: Use a balanced fertilizer, such as a 10-10-10, during the growing season. Apply in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist, watering when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight, at least 4-6 hours of direct sunlight daily.
    - Botanical Name: Vitex negundo
    - Care Tips: Prune to maintain shape. Protect from frost in colder climates.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Holy Basil Plant (Ocimum tenuiflorum)":"""
    - Fertilizer: Use a balanced fertilizer during the growing season. Apply in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal oil production.
    - Botanical Name: Ocimum tenuiflorum
    - Care Tips: Pinch back for bushier growth. Harvest leaves for culinary and medicinal use.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """, 
    "Malabar Nut Plant (Justicia adhatoda)":"""
    - Fertilizer: Use a balanced fertilizer during the growing season. Apply in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Partial to full sunlight.
    - Botanical Name: Justicia adhatoda
    - Care Tips: Prune to maintain shape. Protect from frost in colder climates.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Morinda Citrifolia (Indian Mulberry)":"""
    - Fertilizer: Use a balanced fertilizer with micronutrients every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal fruiting.
    - Botanical Name: Morinda citrifolia
    - Care Tips: Prune to control size. Protect from cold temperatures.
    - Lifespan: Perennial
    - Growing Season: Year-round in warm climates
    """, 
    "Andrographis Paniculata (Green Chiretta)":"""
    - Fertilizer: Use a balanced fertilizer with micronutrients every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Partial sunlight.
    - Botanical Name: Andrographis paniculata
    - Care Tips: Pinch back for bushier growth. Harvest leaves for medicinal use.
    - Lifespan: Annual or perennial
    - Growing Season: Spring and summer
    """,
    "Philodendron":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist but not waterlogged. Water when the top inch of soil feels slightly dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate lower light conditions.
    - Botanical Name: Philodendron spp.
    - Care Tips: Provide support for climbing varieties. Wipe leaves regularly to remove dust. Prune to control size and encourage bushier growth.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Money Plant (Epipremnum aureum, Devil's Ivy, Pothos)":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Allow the top inch of soil to dry before watering. Water sparingly in winter.
    - Sunlight Requirement: Thrives in indirect light but can tolerate low light. Avoid direct sunlight.
    - Botanical Name: Epipremnum aureum
    - Care Tips: Prune to maintain shape and control size. Wipe leaves to keep them clean.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Syngonium":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil evenly moist. Water when the top inch of soil feels slightly dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate lower light conditions.
    - Botanical Name: Syngonium spp.
    - Care Tips: Prune to encourage bushier growth. Provide support for climbing varieties.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Alocasia":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Shield from direct sunlight, which can scorch the leaves.
    - Botanical Name: Alocasia spp.
    - Care Tips: Maintain high humidity. Prune yellow or damaged leaves. Reduce watering in the dormant season (fall and winter).
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Aglaonema":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Thrives in low to bright, indirect light. Avoid prolonged direct sunlight.
    - Botanical Name: Aglaonema spp.
    - Care Tips: Wipe leaves regularly. Prune yellow or damaged leaves. Provide higher humidity if possible.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Caladium":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Indirect light. Avoid direct sunlight, which can scorch the leaves.
    - Botanical Name: Caladium spp.
    - Care Tips: Provide high humidity. Reduce watering in the dormant season (fall and winter). Lift bulbs and store in a cool, dry place during dormancy.
    - Lifespan: Perennial (tuberous root needs to be overwintered)
    - Growing Season: Spring and summer
    """,
    "Ferns":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Mist the leaves regularly to increase humidity.
    - Sunlight Requirement: Indirect light. Avoid direct sunlight, especially in the case of delicate fern varieties.
    - Botanical Name: Various genera (e.g., Nephrolepis, Adiantum)
    - Care Tips: Maintain high humidity. Trim yellow or damaged fronds. Provide good air circulation.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Dracaena":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Allow the top inch of soil to dry before watering. Water more sparingly in winter.
    - Sunlight Requirement: Moderate to bright, indirect light. Can tolerate lower light conditions but avoid direct sunlight.
    - Botanical Name: Dracaena spp.
    - Care Tips: Wipe leaves regularly to remove dust. Prune brown or yellow leaves. Provide good drainage.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Ti-plants (Cordyline)":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some direct sunlight.
    - Botanical Name: Cordyline spp.
    - Care Tips: Remove dead or yellowing leaves. Prune for shape and size control. Provide high humidity if possible.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Ficus":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Allow the top inch of soil to dry before watering.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some direct sunlight.
    - Botanical Name: Ficus spp.
    - Care Tips: Wipe leaves regularly. Prune to maintain shape. Watch for pests like spider mites.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Hedge Plants (e.g., Ligustrum, Buxus)":"""
    - Fertilizer: Use a slow-release, balanced fertilizer in spring and mid-summer.
    - Water Schedule: Keep the soil consistently moist, especially during the establishment phase. Once established, water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight, depending on the specific plant species.
    - Botanical Name: Varies by specific plant (e.g., Ligustrum spp. for Privet, Buxus spp. for Boxwood).
    - Care Tips: Prune regularly to maintain the desired shape. Mulch to conserve soil moisture.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
    """,
    "Aralia":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some shade.
    - Botanical Name: Aralia spp.
    - Care Tips: Wipe leaves regularly. Prune for shape and size control. Provide high humidity if possible.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Alternanthera Ficoidea “True Yellow”":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer). A fertilizer with a higher nitrogen content can enhance foliage color.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight, with preference for morning sunlight.
    - Botanical Name: Alternanthera ficoidea "True Yellow"
    - Care Tips: Pinch back for bushier growth. Trim leggy stems to maintain compactness.
    - Lifespan: Perennial
    - Growing Season: Year-round
 """,
    "Alternanthera Ficoidea White Carpet":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Alternanthera ficoidea "White Carpet"
    - Care Tips: Prune regularly for a dense carpet effect. Maintain soil humidity.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Alternanthera Green":"""
    - Fertilizer: Apply a balanced, water-soluble fertilizer every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Alternanthera spp.
    - Care Tips: Pinch back for bushier growth. Trim to shape and control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Alternanthera, Parrot leaf ‘red carpet’":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Alternanthera spp.
    - Care Tips: Prune for shape and size control. Provide support for sprawling growth.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Callisia Dragon Tail Plant":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Allow the top inch of soil to dry before watering. Keep the soil consistently moist.
    - Sunlight Requirement: Partial to full sunlight.
    - Botanical Name: Callisia fragrans
    - Care Tips: Provide support for trailing stems. Pinch back for bushiness.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Callisia Repens-Turtle Vine Plant":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Partial to full sunlight.
    - Botanical Name: Callisia repens
    - Care Tips: Pinch back for bushier growth. Trim to control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Clitoria Ternatea-White Multi Petaled":"""
    - Fertilizer: Apply a balanced, water-soluble fertilizer every 2-4 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal flowering.
    - Botanical Name: Clitoria ternatea
    - Care Tips: Provide support for climbing vines. Prune to control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Cupid Peperomia Plant":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Allow the top inch of soil to dry before watering. Keep the soil consistently moist.
    - Sunlight Requirement: Indirect light. Can tolerate low light conditions.
    - Botanical Name: Peperomia scandens
    - Care Tips: Wipe leaves regularly. Trim leggy stems for compact growth.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Hanging Pedilanthus-(Curly Leaves Variegated)":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Allow the top inch of soil to dry before watering. Keep the soil consistently moist.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some direct sunlight.
    - Botanical Name: Pedilanthus tithymaloides
    - Care Tips: Provide support for trailing stems. Prune for shape and control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Inch Plant Deep Purple (Tradescantia pallida)":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some direct sunlight.
    - Botanical Name: Tradescantia pallida
    - Care Tips: Pinch back for bushier growth. Trim to control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Melastoma Malabathricum-Indian Rhododendron":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Melastoma malabathricum
    - Care Tips: Prune for shape and size control. Provide support for sprawling growth.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Mexican Petunia Purple Showers (Ruellia simplex)":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Ruellia simplex
    - Care Tips: Prune for shape and size control. Watch for potential invasiveness in some regions.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Pellionia Repens-Trailing Watermelon Begonia":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some shade.
    - Botanical Name: Pellionia repens
    - Care Tips: Provide support for trailing stems. Pinch back for bushier growth.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Purple Heart (Tradescantia pallida) Plant":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some direct sunlight.
    - Botanical Name: Tradescantia pallida
    - Care Tips: Pinch back for bushier growth. Trim to control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Tradescantia Spathacea- Rheo Green":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some direct sunlight.
    - Botanical Name: Tradescantia spathacea
    - Care Tips: Pinch back for bushier growth. Trim to control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Tradescantia Zebrina":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Bright, indirect light. Can tolerate some direct sunlight.
    - Botanical Name: Tradescantia zebrina
    - Care Tips: Pinch back for bushier growth. Trim to control size.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Bush Clock Laurifolia Blue":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Thunbergia erecta
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Year-round
    """,
    "Bush Clock Vine White":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Thunbergia erecta
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Year-round
 """,
    "Garlic Creeper Plant (Blue)":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Cyanotis somaliensis
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Year-round
 """,
    "Japanese Honeysuckle":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Lonicera japonica
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Spring and summer
 """,
    "Passion Flowers Red":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal flowering.
    - Botanical Name: Passiflora spp.
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Year-round
 """,
    "Thunbergia Grandiflora Blue":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Thunbergia grandiflora
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Year-round
 """,
    "Rangoon Creeper Plant":"""
    - Fertilizer: Apply a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight for optimal flowering.
    - Botanical Name: Quisqualis indica
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Year-round
 """,
    "Bignonia-Amphilophium Paniculatum":"""
    - Fertilizer: Use a balanced liquid fertilizer, diluted to half strength, every 4-6 weeks during the growing season (spring and summer).
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil is dry.
    - Sunlight Requirement: Full to partial sunlight.
    - Botanical Name: Amphilophium paniculatum
    - Care Tips: Provide support for climbing vines. Prune for shape and size control.
    - Lifespan: Perennial
    - Growing Season: Year-round
 """, 
    "L49 White Guava (Lucknow49)":"""
   - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season (spring and summer) every 4-6 weeks.
   - Water Schedule: Keep the soil consistently moist, allowing the top inch to dry between watering.
   - Sunlight Requirement: Full sun (at least 6-8 hours of direct sunlight).
   - Botanical Name: Psidium guajava 'Lucknow49'.
   - Care Tips: Prune to shape and remove dead wood. Mulch to retain moisture.
   - Lifespan: 30-40 years.
   - Growing Season: Spring and summer.
 """,
    "Mini Orange":"""
   - Fertilizer: Use a citrus-specific fertilizer with a balanced ratio (8-8-8) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist, watering when the top inch feels dry.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Citrus sinensis (for sweet oranges).
   - Care Tips: Protect from frost, prune dead or diseased branches, and provide well-draining soil.
   - Lifespan: 50-100 years.
   - Growing Season: Spring and summer.
 """,
    "Star Gooseberry (Phyllanthus acidus)":"""
   - Fertilizer: Apply a balanced fertilizer (10-10-10) in spring and early summer.
   - Water Schedule: Water regularly, allowing the soil to dry slightly between waterings.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Phyllanthus acidus.
   - Care Tips: Prune for shape, protect from frost, and provide well-draining soil.
   - Lifespan: Up to 100 years.
   - Growing Season: Spring and summer.
 """,
    "Allahabad Safeda Guava Plant":"""
   - Fertilizer: Use a balanced fertilizer (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist, especially during flowering and fruiting.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Psidium guajava 'Allahabad Safeda'.
   - Care Tips: Prune to improve air circulation, protect from pests, and provide winter protection in colder regions.
   - Lifespan: 30-40 years.
   - Growing Season: Spring and summer.
 """,
    "Arka Kiran Guava (Pink Koiyya Plant)":"""
   - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
   - Water Schedule: Keep the soil consistently moist, especially during flowering and fruiting.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Psidium guajava 'Arka Kiran'.
   - Care Tips: Prune to shape, provide support for heavy fruiting branches, and protect from frost.
   - Lifespan: 30-40 years.
   - Growing Season: Spring and summer.
 """,
    "Barbados Cherry Plant":"""
   - Fertilizer: Use a balanced fertilizer (10-10-10) with added micronutrients every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist, especially during dry periods.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Malpighia emarginata.
   - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
   - Lifespan: 20-30 years.
   - Growing Season: Spring and summer.
 """,
    "Dragon Fruit Plant":"""
   - Fertilizer: Use a balanced cactus or succulent fertilizer (2-7-7) during the growing season every 4-6 weeks.
   - Water Schedule: Water sparingly, allowing the soil to dry between waterings.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Hylocereus undatus.
   - Care Tips: Provide support for climbing stems, protect from frost, and use well-draining soil.
   - Lifespan: 15-20 years.
   - Growing Season: Spring and summer.
 """,
    "Mini Guava Green":"""
   - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
   - Water Schedule: Keep the soil consistently moist, especially during flowering and fruiting.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Psidium guajava.
   - Care Tips: Prune to shape, provide support for heavy fruiting branches, and protect from frost.
   - Lifespan: 30-40 years.
   - Growing Season: Spring and summer.
 """,
    "Water Apple Red":"""
   - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
   - Water Schedule: Keep the soil consistently moist, especially during flowering and fruiting.
   - Sunlight Requirement: Full sun.
   - Botanical Name: Syzygium samarangense.
   - Care Tips: Prune for shape, provide support for heavy fruiting branches, and protect from pests.
   - Lifespan: 20-30 years.
   - Growing Season: Spring and summer.
 """,
    "Aegle Marmelos (Kasi Vilvam)":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
    - Water Schedule: Keep the soil consistently moist, especially during dry periods.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Aegle marmelos.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 50-100 years.
    - Growing Season: Spring and summer.
 """,
    "Jamun Fruit (Naval Maram)":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
    - Water Schedule: Keep the soil consistently moist, especially during flowering and fruiting.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Syzygium cumini.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 40-60 years.
    - Growing Season: Spring and summer.
 """,
    "Kadamba Tree":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) in spring and early summer.
    - Water Schedule: Water regularly, allowing the soil to dry slightly between waterings.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Neolamarckia cadamba.
    - Care Tips: Prune to remove dead wood, protect from pests, and provide well-draining soil.
    - Lifespan: 50-100 years.
    - Growing Season: Spring and summer.
 """,
    "Indian Tulip Tree":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) in spring and early summer.
    - Water Schedule: Keep the soil consistently moist, especially during the growing season.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Thespesia populnea.
    - Care Tips: Prune to shape, protect from pests, and provide well-draining soil.
    - Lifespan: 50-100 years.
    - Growing Season: Spring and summer.
 """,
    "Kumizh (Gmelina Arborea Tree - White Teak)":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) in spring and early summer.
    - Water Schedule: Water regularly, allowing the soil to dry slightly between waterings.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Gmelina arborea.
    - Care Tips: Prune to remove dead wood, protect from pests, and provide well-draining soil.
    - Lifespan: 50-100 years.
    - Growing Season: Spring and summer.
 """,
    "Madras Thorn Plant (Kodukka Puli)":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
    - Water Schedule: Keep the soil consistently moist, especially during dry periods.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Pithecellobium dulce.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 20-30 years.
    - Growing Season: Spring and summer.
 """,
    "Casuarina Plant (Savukku Maram)":"""
    - Fertilizer: Use a nitrogen-rich fertilizer (20-10-10) in spring and early summer.
    - Water Schedule: Water regularly, especially during the growing season.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Casuarina equisetifolia.
    - Care Tips: Prune to shape, protect from pests, and provide well-draining soil.
    - Lifespan: 30-50 years.
    - Growing Season: Spring and summer.
 """,
    "Lakshmi Tree (Simarouba Glauca)":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) in spring and early summer.
    - Water Schedule: Keep the soil consistently moist, especially during dry periods.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Simarouba glauca.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 50-100 years.
    - Growing Season: Spring and summer.
 """,
    "Mahua Tree (Iluppai Maram)":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) in spring and early summer.
    - Water Schedule: Water regularly, allowing the soil to dry slightly between waterings.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Madhuca longifolia.
    - Care Tips: Prune to shape, protect from pests, and provide well-draining soil.
    - Lifespan: 50-100 years.
    - Growing Season: Spring and summer.
 """,
    "Apple Plant":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
    - Water Schedule: Keep the soil consistently moist, especially during dry periods.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Malus domestica.
    - Care Tips: Prune to shape, protect from pests, and provide well-draining soil.
    - Lifespan: 15-30 years.
    - Growing Season: Spring and summer.
 """,
    "Mango Plant":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
    - Water Schedule: Keep the soil consistently moist, especially during flowering and fruiting.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Mangifera indica.
    - Care Tips: Prune to shape, protect from pests, and provide well-draining soil.
    - Lifespan: 40-60 years.
    - Growing Season: Spring and summer.
 """,
    "Lychee Plant":"""
    - Fertilizer: Use a balanced fertilizer (10-10-10) during the growing season every 4-6 weeks.
    - Water Schedule: Keep the soil consistently moist, especially during flowering and fruiting.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Litchi chinensis.
    - Care Tips: Prune to shape, protect from pests, and provide well-draining soil.
    - Lifespan: 50-150 years.
    - Growing Season: Spring and summer.
 """,
    "Avocado Plant":"""
    - Fertilizer: Use a balanced fertilizer (8-3-9) during the growing season every 4-6 weeks.
    - Water Schedule: Keep the soil consistently moist, allowing the top inch to dry between waterings.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Persea americana.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 40-80 years.
    - Growing Season: Spring and summer
 """,
    "Bitter Gourd Plant (Paavakkaai)":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during flowering. Additionally, provide a nitrogen-rich fertilizer during vegetative growth.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Momordica charantia
    - Care Tips: Provide support for climbing varieties. Mulch to retain soil moisture. Control pests like aphids and mites.
    - Lifespan: Annual
    - Growing Season: Spring to early summer
 """,
    "Pumpkin Plant (Parangikai)":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during fruit development. Add compost for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Cucurbita pepo
    - Care Tips: Provide space for vines to spread. Mulch to suppress weeds and retain moisture.
    - Lifespan: Annual
    - Growing Season: Late spring to early fall
 """,
    "Fava Beans/Broad Beans (Avarai)":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during flowering. Add organic matter like well-rotted compost.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Vicia faba
    - Care Tips: Provide support for tall varieties. Control aphids and beetles.
    - Lifespan: Annual
    - Growing Season: Cool season (spring or fall)
 """,
    "Brinjal Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during fruit development. Add compost for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Solanum melongena
    - Care Tips: Stake taller varieties. Control pests like aphids and caterpillars.
    - Lifespan: Annual
    - Growing Season: Late spring to early fall
 """,
    "Ash Pumpkin Plant (Poosanaikkaai)":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during fruit development. Add compost for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Cucurbita maxima
    - Care Tips: Provide space for vines to spread. Mulch to suppress weeds and retain moisture.
    - Lifespan: Annual
    - Growing Season: Late spring to early fall
 """,
    "Spinach Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during early growth. Add organic matter for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Partial shade to full sunlight.
    - Botanical Name: Spinacia oleracea
    - Care Tips: Harvest outer leaves first. Protect from extreme heat to prevent bolting.
    - Lifespan: Annual
    - Growing Season: Cool season (spring or fall)
 """,
    "Lettuce Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during early growth. Add organic matter for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Partial shade to full sunlight.
    - Botanical Name: Lactuca sativa
    - Care Tips: Harvest outer leaves first. Protect from extreme heat to prevent bolting.
    - Lifespan: Annual
    - Growing Season: Cool season (spring or fall)
 """,
    "Radishes Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting. Avoid excessive nitrogen to prevent excessive foliage.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Raphanus sativus
    - Care Tips: Thin seedlings to avoid overcrowding. Harvest promptly to prevent pithiness.
    - Lifespan: Annual
    - Growing Season: Cool season (spring or fall)
 """,
    "Potatoes Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 5-10-10, applied at planting. Add organic matter like compost for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Solanum tuberosum
    - Care Tips: Mulch to suppress weeds. Hill soil around emerging stems.
    - Lifespan: Annual
    - Growing Season: Late spring to early fall
 """,
    "Tomatoes Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 5-10-10, applied at planting and during fruit development. Add compost for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Solanum lycopersicum
    - Care Tips: Stake for support. Prune to improve airflow and reduce disease risk.
    - Lifespan: Annual
    - Growing Season: Late spring to early fall
 """,
    "Salad Leaves":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during early growth. Add organic matter for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Partial shade to full sunlight.
    - Botanical Name: Various (lettuce, spinach, arugula, etc.)
    - Care Tips: Harvest outer leaves first. Protect from extreme heat to prevent bolting.
    - Lifespan: Annual
    - Growing Season: Cool season (spring or fall)
 """,
    "Spring Onions Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting and during early growth. Add compost for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Allium fistulosum
    - Care Tips: Harvest when young for milder flavor. Mulch to conserve soil moisture.
    - Lifespan: Perennial (harvest as an annual)
    - Growing Season: Cool season (spring or fall)
 """,
    "Carrot Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting. Avoid excessive nitrogen to prevent forked roots.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Daucus carota
    - Care Tips: Thin seedlings to avoid overcrowding. Harvest promptly to prevent pithiness.
    - Lifespan: Biennial (harvest as an annual)
    - Growing Season: Cool season (spring or fall)
 """,
    "Beetroot Plant":"""
    - Fertilizer: Use a balanced fertilizer with a ratio of 10-10-10, applied at planting. Add organic matter like compost for soil enrichment.
    - Water Schedule: Keep the soil consistently moist. Water deeply when the top inch of soil is dry.
    - Sunlight Requirement: Full sunlight.
    - Botanical Name: Beta vulgaris
    - Care Tips: Thin seedlings to avoid overcrowding. Harvest promptly to prevent toughness.
    - Lifespan: Biennial (harvest as an annual)
    - Growing Season: Cool season (spring or fall)
 """,
    "3 Pink Lotus Tuber":"""
   - Fertilizer: Use a pond fertilizer tablet with a balanced formula (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently wet. Plant the tubers in shallow water (1-2 feet deep).
   - Sunlight Requirement: Full sunlight (at least 6 hours of direct sunlight per day).
   - Botanical Name: Nelumbo nucifera
   - Care Tips: Provide well-aerated soil. Remove dead or decaying leaves regularly.
   - Lifespan: Perennial
   - Growing Season: Late spring to early fall
 """,
    "3 White Lily Plant":"""
   - Fertilizer: Use a fertilizer specially formulated for water lilies, with a higher phosphorus content, every 3-4 weeks during the growing season.
   - Water Schedule: Keep the soil consistently wet. Plant in containers and submerge in water 6-18 inches deep.
   - Sunlight Requirement: Full sunlight.
   - Botanical Name: Nymphaea spp.
   - Care Tips: Prune dead leaves and flowers. Divide and repot every 2-3 years.
   - Lifespan: Perennial
   - Growing Season: Late spring to early fall
 """,
    "Hydrocleys Nymphoides":"""
   - Fertilizer: Use a balanced aquatic fertilizer every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently wet, with the plant submerged in shallow water (6-12 inches deep).
   - Sunlight Requirement: Full sunlight to partial shade.
   - Botanical Name: Hydrocleys nymphoides
   - Care Tips: Provide well-aerated soil. Divide the plant every 1-2 years.
   - Lifespan: Perennial
   - Growing Season: Late spring to early fall
 """,
    "Ludwigia Sedoides":"""
   - Fertilizer: Use an aquatic plant fertilizer with a higher nitrogen content every 4 weeks during the growing season.
   - Water Schedule: Keep the soil consistently wet. Plant in shallow water (6-12 inches deep).
   - Sunlight Requirement: Full sunlight.
   - Botanical Name: Ludwigia sedoides
   - Care Tips: Trim and prune regularly to encourage bushy growth. Provide well-aerated soil.
   - Lifespan: Annual or perennial depending on conditions
   - Growing Season: Late spring to early fall
 """,
    "Rhynchospora Colorata":"""
   - Fertilizer: Use a slow-release aquatic fertilizer with micronutrients every 6-8 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Plant in shallow water (6-12 inches deep).
   - Sunlight Requirement: Full to partial sunlight.
   - Botanical Name: Rhynchospora colorata
   - Care Tips: Remove dead or yellowing leaves. Mulch to retain soil moisture.
   - Lifespan: Perennial
   - Growing Season: Late spring to early fall
 """,
    "Water Lily":"""
   - Fertilizer: Use a specialized water lily fertilizer with a higher phosphorus content every 3-4 weeks during the growing season.
   - Water Schedule: Plant in containers and submerge 6-18 inches deep. Keep the soil consistently wet.
   - Sunlight Requirement: Full sunlight.
   - Botanical Name: Nymphaea spp.
   - Care Tips: Prune dead leaves and flowers regularly. Divide and repot every 2-3 years.
   - Lifespan: Perennial
   - Growing Season: Late spring to early fall
 """,
    "Water Lily Purple Plant":"""
   - Fertilizer: Use a water lily fertilizer with a higher phosphorus content every 3-4 weeks during the growing season.
   - Water Schedule: Plant in containers and submerge 6-18 inches deep. Keep the soil consistently wet.
   - Sunlight Requirement: Full sunlight.
   - Botanical Name: Nymphaea spp.
   - Care Tips: Prune dead leaves and flowers regularly. Divide and repot every 2-3 years.
   - Lifespan: Perennial
   - Growing Season: Late spring to early fall
 """,
    "Croton Plants":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 2-4 weeks during the growing season (spring and summer).
   - Water Schedule: Keep the soil consistently moist but not waterlogged. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Bright, indirect light to full sun.
   - Botanical Name: Codiaeum variegatum.
   - Care Tips: Provide high humidity, prune for shape, and watch for pests. Crotons may drop leaves if conditions change.
   - Lifespan: 10-20 years.
   - Growing Season: Spring and summer.
 """,
    "Acalpha wilkesiana - Jacob’s Coat":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Acalypha wilkesiana.
   - Care Tips: Prune regularly for bushiness, watch for pests, and provide well-draining soil.
   - Lifespan: 5-10 years.
   - Growing Season: Spring and summer.
 """,
    "Acalypha Copper Plant - Dragon Fire":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Acalypha wilkesiana.
   - Care Tips: Prune to maintain shape, protect from strong winds, and provide well-draining soil.
   - Lifespan: 5-10 years.
   - Growing Season: Spring and summer.
 """,
    "Aralia Green Plant":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Partial shade to full sun.
   - Botanical Name: Polyscias fruticosa.
   - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
   - Lifespan: 10-20 years.
   - Growing Season: Spring and summer.
 """,
    "Aralia Variegated White":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Partial shade to full sun.
   - Botanical Name: Polyscias fruticosa.
   - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
   - Lifespan: 10-20 years.
   - Growing Season: Spring and summer.
 """,
    "Carpentaria Palm":"""
   - Fertilizer: Use a palm fertilizer (8-2-12) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Carpentaria acuminata.
   - Care Tips: Provide high humidity, protect from cold drafts, and watch for pests.
   - Lifespan: 30-50 years.
   - Growing Season: Spring and summer.
 """,
    "Chinese Hat Flower":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Holmskioldia sanguinea.
   - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
   - Lifespan: 10-20 years.
   - Growing Season: Spring and summer.
 """,
    "Carmona Microphylla - Fukien Tea Croton":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Carmona microphylla.
   - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
   - Lifespan: 10-20 years.
   - Growing Season: Spring and summer.
 """,
    "Codiaeum Variegatum - Garden Croton":"""
   - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 2-4 weeks during the growing season.
   - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
   - Sunlight Requirement: Full sun to partial shade.
   - Botanical Name: Codiaeum variegatum.
   - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
   - Lifespan: 10-20 years.
   - Growing Season: Spring and summer.
 """,
    "Codiaeum Variegatum 'Robert Lavalois'":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 2-4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Codiaeum variegatum.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 10-20 years.
    - Growing Season: Spring and summer.
 """,
    "Copperleaf":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Acalypha wilkesiana.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 5-10 years.
    - Growing Season: Spring and summer.
 """,
    "Cordyline 'Chocolate Queen'":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Partial shade to full sun.
    - Botanical Name: Cordyline fruticosa.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 10-20 years.
    - Growing Season: Spring and summer.
 """,
    "Cordyline fruticosa 'Celestial Queen'":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Partial shade to full sun.
    - Botanical Name: Cordyline fruticosa.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 10-20 years.
    - Growing Season: Spring and summer.
 """,
    "Cordyline fruticosa 'Inscripta'":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Partial shade to full sun.
    - Botanical Name: Cordyline fruticosa.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 10-20 years.
    - Growing Season: Spring and summer.
 """,
    "Duck Foot Plant":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Syngonium podophyllum.
    - Care Tips: Provide high humidity, protect from drafts, and prune for shape.
    - Lifespan: 5-10 years.
    - Growing Season: Spring and summer.
 """,
    "Euphorbia tithymaloides variegated plant":"""
    - Fertilizer: Use a diluted balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Allow the soil to dry out between waterings. Water sparingly.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Pedilanthus tithymaloides.
    - Care Tips: Protect from overwatering, provide well-draining soil, and watch for pests.
    - Lifespan: 5-10 years.
    - Growing Season: Spring and summer.
 """,
    "Gold Dust (Small Leaf)":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 2-4 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Partial shade to full sun.
    - Botanical Name: Aucuba japonica.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 20-30 years.
    - Growing Season: Spring and summer.
 """,
    "Hybrid Ti Plant":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Partial shade to full sun.
    - Botanical Name: Cordyline fruticosa.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 10-20 years.
    - Growing Season: Spring and summer.
 """,
    "Pandanus Tectorius - Screw Pine":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Full sun.
    - Botanical Name: Pandanus tectorius.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 20-40 years.
    - Growing Season: Spring and summer.
 """,
    "Pedilanthus Tithymaloides":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Allow the soil to dry out between waterings. Water sparingly.
    - Sunlight Requirement: Full sun to partial shade.
    - Botanical Name: Pedilanthus tithymaloides.
    - Care Tips: Protect from overwatering, provide well-draining soil, and watch for pests.
    - Lifespan: 5-10 years.
    - Growing Season: Spring and summer.
 """,
    "Polyscias Fruticosa Plant":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Partial shade to full sun.
    - Botanical Name: Polyscias fruticosa.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 10-20 years.
    - Growing Season: Spring and summer.
 """,
    "Song of India Green Plant":"""
    - Fertilizer: Use a balanced liquid fertilizer (10-10-10) every 4-6 weeks during the growing season.
    - Water Schedule: Keep the soil consistently moist. Water when the top inch of soil feels dry.
    - Sunlight Requirement: Partial shade to full sun.
    - Botanical Name: Dracaena reflexa.
    - Care Tips: Prune for shape, protect from pests, and provide well-draining soil.
    - Lifespan: 10-20 years.
    - Growing Season: Spring and summer.
 """,
 #END HAI BHAI
}

root = tk.Tk()
root.title("Plant Care Assistance")
root.configure(bg="#f0fff0")
welcome_label = tk.Label(root, text="Welcome to Plant Care Assistance", font=("Helvetica", 16), bg="#f0fff0", fg="dark green")
welcome_label.pack(pady=10)
plant_type_var = tk.StringVar()
plant_type_label = tk.Label(root, text="Type of Plants", font=("Helvetica", 12), bg="#f0fff0", fg="dark green")
plant_type_combobox = ttk.Combobox(root, textvariable=plant_type_var, values=[ "Flower Plants", "Herbal Plants", "Indoor Plants", "Ornamental Plants", "Hanging and Creeper Plants", "Fruit Plants", "Vegetable Plants", "Aquatic Plants", "Croton Plants"
], state="readonly", background="#f0fff0")
plant_type_label.pack(pady=10)
plant_type_combobox.pack(pady=10)
plant_options_label = tk.Label(root, text="Plant Options", font=("Helvetica", 12), bg="#f0fff0", fg="dark green")
plant_options_var = tk.StringVar()
plant_options_combobox = ttk.Combobox(root, textvariable=plant_options_var, state="readonly", background="light green")
plant_options_label.pack(pady=10)
plant_options_combobox.pack(pady=10)
display_button = tk.Button(root, text="Display Plant Options", command=display_plant_options, bg="light green", fg="dark green")
display_button.pack(pady=10)
select_button = tk.Button(root, text="Select Plant", command=select_plant, bg="light green", fg="dark green")
select_button.pack(pady=10)
result_label = tk.Label(root, text="", font=("Helvetica", 12), bg="#f0fff0", fg="dark green")
result_label.pack(pady=10)
root.mainloop()