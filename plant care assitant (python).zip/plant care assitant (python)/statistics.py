import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

flower_plants_list = ["Rose", "Crape Layered Jasmine", "Kodai Malli", "Mussaenda Yellow Mini", "Nerium Oleander Plant White", "Crossandra Yellow", "Bulb Sampangi Plant", "Allamanda Bush Yellow Plant", "Singapuri Ixora Red Plant", "Mussaenda Red Plant", "Kesavardhini Plant", "Lily", "Tulip", "Daisy", "Sunflower"]
herbal_plants_list = ["Basil", "Mint", "Lavender", "Rosemary", "Thyme"]
indoor_plants_list = ["Spider Plant", "Peace Lily", "Snake Plant", "ZZ Plant", "Pothos"]


class PlantCareApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Plant Care Assistance")
        self.root.geometry("800x600")

        self.user_analytics = {'Flower Plants': 0, 'Herbal Plants': 0, 'Indoor Plants': 0}

        self.welcome_label = tk.Label(root, text="Welcome to Plant Care Assistance", font=("Helvetica", 16))
        self.welcome_label.pack(pady=10)

        self.plant_type_var = tk.StringVar()
        self.plant_type_label = tk.Label(root, text="Type of Plants", font=("Helvetica", 12))
        self.plant_type_combobox = ttk.Combobox(root, textvariable=self.plant_type_var,
                                                values=["Flower Plants", "Herbal Plants", "Indoor Plants"],
                                                state="readonly")
        self.plant_type_combobox.bind("<<ComboboxSelected>>", self.update_user_analytics)
        self.plant_type_label.pack(pady=10)
        self.plant_type_combobox.pack(pady=10)

        self.plant_options_label = tk.Label(root, text="Plant Options", font=("Helvetica", 12))
        self.plant_options_var = tk.StringVar()
        self.plant_options_combobox = ttk.Combobox(root, textvariable=self.plant_options_var, state="readonly")
        self.plant_options_label.pack(pady=10)
        self.plant_options_combobox.pack(pady=10)

        self.select_button = tk.Button(root, text="Select Plant", command=self.select_plant)
        self.select_button.pack(pady=10)

        self.analytics_frame = tk.Frame(root)
        self.analytics_frame.pack(pady=10)

        self.fig, self.ax = plt.subplots(figsize=(5, 3), tight_layout=True)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.analytics_frame)
        self.canvas.get_tk_widget().pack()

    def update_user_analytics(self, event):
        selected_type = self.plant_type_var.get()
        if selected_type in self.user_analytics:
            self.user_analytics[selected_type] += 1
            self.display_bar_graph()

    def display_bar_graph(self):
        self.ax.clear()
        plant_types = list(self.user_analytics.keys())
        counts = list(self.user_analytics.values())
        self.ax.bar(plant_types, counts, color='green')
        self.ax.set_ylabel('Number of Selections')
        self.ax.set_title('User Analytics')
        self.canvas.draw()

    def select_plant(self):
        selected_plant = self.plant_options_combobox.get()
        if selected_plant:
            tk.messagebox.showinfo("Selection", f"You selected: {selected_plant}")

root = tk.Tk()

app = PlantCareApp(root)

root.mainloop()